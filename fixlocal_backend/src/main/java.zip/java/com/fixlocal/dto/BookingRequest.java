package com.fixlocal.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class BookingRequest {

    @NotBlank(message = "Tradesperson ID is required")
    private String tradespersonId;

    @NotNull(message = "Booking start time is required")
    private LocalDateTime bookingStartTime;

    @NotNull(message = "Booking end time is required")
    private LocalDateTime bookingEndTime;

    @NotBlank(message = "Service address is required")
    private String serviceAddress;

    private String serviceDescription;

    private Double price;
}