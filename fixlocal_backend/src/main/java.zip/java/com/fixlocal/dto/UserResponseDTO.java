package com.fixlocal.dto;

import com.fixlocal.model.Role;
import com.fixlocal.model.Status;
import lombok.Data;

@Data
public class UserResponseDTO {

    private String id;
    private String name;
    private String email;
    private Role role;

    private String occupation;
    private String workingCity;
    private int experience;

    private double averageRating;
    private int totalReviews;

    private Status status;
    private boolean verified;
}