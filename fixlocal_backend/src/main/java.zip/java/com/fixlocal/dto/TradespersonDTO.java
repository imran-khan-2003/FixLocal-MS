package com.fixlocal.dto;

import com.fixlocal.model.Status;
import lombok.Data;

@Data
public class TradespersonDTO {

    private String id;
    private String name;
    private String occupation;
    private String workingCity;
    private int experience;

    private double averageRating;
    private int totalReviews;

    private boolean verified;

    // ⭐ Added for frontend
    private Status status;
}