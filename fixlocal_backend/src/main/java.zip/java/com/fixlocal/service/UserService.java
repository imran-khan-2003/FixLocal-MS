package com.fixlocal.service;

import com.fixlocal.dto.UpdateUserRequest;
import com.fixlocal.dto.UserResponseDTO;
import com.fixlocal.exception.ResourceNotFoundException;
import com.fixlocal.model.User;
import com.fixlocal.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    public UserResponseDTO getMyProfile(String email) {
        System.out.println("Email from authentication: " + email);
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        return mapToDTO(user);
    }

    public UserResponseDTO updateMyProfile(String email, UpdateUserRequest request) {

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        user.setName(request.getName());
        user.setWorkingCity(request.getWorkingCity());

        userRepository.save(user);

        return mapToDTO(user);
    }

    private UserResponseDTO mapToDTO(User user) {

        UserResponseDTO dto = new UserResponseDTO();

        dto.setId(user.getId());
        dto.setName(user.getName());
        dto.setEmail(user.getEmail());
        dto.setRole(user.getRole());

        dto.setOccupation(user.getOccupation());
        dto.setWorkingCity(user.getWorkingCity());
        dto.setExperience(user.getExperience());

        dto.setAverageRating(user.getAverageRating());
        dto.setTotalReviews(user.getTotalReviews());

        dto.setStatus(user.getStatus());
        dto.setVerified(user.isVerified());

        return dto;
    }
}