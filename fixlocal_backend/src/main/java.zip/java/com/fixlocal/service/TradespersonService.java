package com.fixlocal.service;

import com.fixlocal.dto.TradespersonDTO;
import com.fixlocal.exception.BadRequestException;
import com.fixlocal.exception.ResourceNotFoundException;
import com.fixlocal.model.*;
import com.fixlocal.repository.UserRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class TradespersonService {

    private final UserRepository userRepository;

    // ======================================================
    // SEARCH TRADESPERSONS
    // ======================================================

    public Page<TradespersonDTO> searchTradespersons(
            String city,
            String occupation,
            Double minRating,
            int page,
            int size
    ) {

        if (city == null || city.isBlank()) {
            throw new BadRequestException("City is required");
        }

        Pageable pageable = PageRequest.of(page, size);

        Page<User> users;

        // ⭐ SEARCH WITH OCCUPATION
        if (occupation != null && !occupation.isBlank()) {

            users = userRepository
                    .findByRoleAndWorkingCityIgnoreCaseAndOccupationIgnoreCaseAndStatusAndVerifiedTrueAndBlockedFalse(
                            Role.TRADESPERSON,
                            city.trim(),
                            occupation.trim(),
                            Status.AVAILABLE,
                            pageable
                    );

        }

        // ⭐ SEARCH WITHOUT OCCUPATION
        else {

            users = userRepository
                    .findByRoleAndWorkingCityIgnoreCaseAndStatusAndVerifiedTrueAndBlockedFalse(
                            Role.TRADESPERSON,
                            city.trim(),
                            Status.AVAILABLE,
                            pageable
                    );
        }

        List<TradespersonDTO> dtoList = users.getContent()
                .stream()
                .filter(user ->
                        minRating == null ||
                                user.getAverageRating() >= minRating
                )
                .map(this::mapToDTO)
                .toList();

        return new PageImpl<>(dtoList, pageable, users.getTotalElements());
    }

    // ======================================================
    // GET SINGLE TRADESPERSON
    // ======================================================

    public TradespersonDTO getTradespersonById(String id) {

        User tradesperson = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Tradesperson not found"));

        if (tradesperson.getRole() != Role.TRADESPERSON) {
            throw new BadRequestException("User is not a tradesperson");
        }

        return mapToDTO(tradesperson);
    }

    // ======================================================
    // DTO MAPPER
    // ======================================================

    private TradespersonDTO mapToDTO(User user) {

        TradespersonDTO dto = new TradespersonDTO();

        dto.setId(user.getId());
        dto.setName(user.getName());
        dto.setOccupation(user.getOccupation());
        dto.setWorkingCity(user.getWorkingCity());
        dto.setExperience(user.getExperience());
        dto.setAverageRating(user.getAverageRating());
        dto.setTotalReviews(user.getTotalReviews());
        dto.setVerified(user.isVerified());
        dto.setStatus(user.getStatus());

        return dto;
    }
}