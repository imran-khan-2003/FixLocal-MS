package com.fixlocal.service;

import com.fixlocal.dto.BookingRequest;
import com.fixlocal.model.*;
import com.fixlocal.repository.BookingRepository;
import com.fixlocal.repository.UserRepository;
import com.fixlocal.exception.*;
import com.fixlocal.dto.BookingStatsDTO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.data.domain.*;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.*;
import org.springframework.data.mongodb.core.aggregation.*;

import com.mongodb.client.result.UpdateResult;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class BookingService {

    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;
    private final MongoTemplate mongoTemplate;

    // ======================================================
    // 🔐 Helper: Get logged-in user (BLOCK SAFE)
    // ======================================================
    private User getLoggedInUser() {

        String email = SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getName();

        User user = userRepository.findByEmail(email)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User not found"));

        if (user.isBlocked()) {
            throw new UnauthorizedException("Your account is blocked");
        }

        return user;
    }

    // ======================================================
    // ✅ CREATE BOOKING
    // ======================================================
    @Transactional
    public Booking createBooking(BookingRequest request) {

        User user = getLoggedInUser();

        if (user.getRole() != Role.USER) {
            throw new UnauthorizedException("Only users can create bookings");
        }

        String tradespersonId = request.getTradespersonId();

        User tradesperson = userRepository.findById(tradespersonId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Tradesperson not found"));

        if (tradesperson.getRole() != Role.TRADESPERSON) {
            throw new BadRequestException("Selected user is not a tradesperson");
        }

        if (!tradesperson.isVerified()) {
            throw new ConflictException("Tradesperson is not verified yet");
        }

        if (tradesperson.isBlocked()) {
            throw new ConflictException("Tradesperson account is blocked");
        }

        if (tradesperson.getStatus() != Status.AVAILABLE) {
            throw new ConflictException("Tradesperson is currently busy");
        }

        // 🔥 TIME VALIDATION
        if (request.getBookingEndTime().isBefore(request.getBookingStartTime())) {
            throw new BadRequestException("Invalid booking time range");
        }

        // 🔥 SLOT CONFLICT CHECK
        var overlappingBookings =
                bookingRepository
                        .findByTradespersonIdAndBookingStartTimeLessThanAndBookingEndTimeGreaterThan(
                                tradespersonId,
                                request.getBookingEndTime(),
                                request.getBookingStartTime()
                        );

        if (!overlappingBookings.isEmpty()) {
            throw new ConflictException(
                    "Tradesperson already has a booking in this time slot"
            );
        }

        boolean alreadyPending = bookingRepository
                .existsByUserIdAndTradespersonIdAndStatus(
                        user.getId(),
                        tradespersonId,
                        BookingStatus.PENDING
                );

        if (alreadyPending) {
            throw new ConflictException(
                    "You already have a pending booking with this tradesperson"
            );
        }

        Booking booking = Booking.builder()
                .userId(user.getId())
                .tradespersonId(tradespersonId)
                .bookingStartTime(request.getBookingStartTime())
                .bookingEndTime(request.getBookingEndTime())
                .serviceAddress(request.getServiceAddress())
                .serviceDescription(request.getServiceDescription())
                .price(request.getPrice())
                .status(BookingStatus.PENDING)
                .createdAt(LocalDateTime.now())
                .build();

        log.info("Booking created by user {} for tradesperson {}",
                user.getId(),
                tradespersonId);

        return bookingRepository.save(booking);
    }
    // ======================================================
    // ✅ ACCEPT BOOKING (CONCURRENCY SAFE)
    // ======================================================
    @Transactional
    public Booking acceptBooking(String bookingId) {

        User loggedInUser = getLoggedInUser();

        if (loggedInUser.getRole() != Role.TRADESPERSON) {
            throw new UnauthorizedException("Only tradesperson can accept booking");
        }

        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Booking not found"));

        if (!booking.getTradespersonId().equals(loggedInUser.getId())) {
            throw new UnauthorizedException("You are not authorized to accept this booking");
        }

        if (booking.getStatus() != BookingStatus.PENDING) {
            throw new BadRequestException("Only pending bookings can be accepted");
        }

        Query query = new Query(
                Criteria.where("_id").is(loggedInUser.getId())
                        .and("status").is(Status.AVAILABLE)
        );

        Update update = new Update().set("status", Status.BUSY);

        UpdateResult result = mongoTemplate.updateFirst(query, update, User.class);

        if (result.getModifiedCount() == 0) {
            throw new ConflictException("You already have an active booking");
        }

        booking.setStatus(BookingStatus.ACCEPTED);

        log.info("Booking {} accepted by tradesperson {}", bookingId, loggedInUser.getId());

        return bookingRepository.save(booking);
    }

    // ======================================================
    // ✅ REJECT BOOKING
    // ======================================================
    @Transactional
    public Booking rejectBooking(String bookingId) {

        User loggedInUser = getLoggedInUser();

        if (loggedInUser.getRole() != Role.TRADESPERSON) {
            throw new UnauthorizedException("Only tradesperson can reject booking");
        }

        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Booking not found"));

        if (!booking.getTradespersonId().equals(loggedInUser.getId())) {
            throw new UnauthorizedException("You are not authorized to reject this booking");
        }

        if (booking.getStatus() != BookingStatus.PENDING) {
            throw new BadRequestException("Only pending bookings can be rejected");
        }

        booking.setStatus(BookingStatus.REJECTED);

        log.info("Booking {} rejected by tradesperson {}", bookingId, loggedInUser.getId());

        return bookingRepository.save(booking);
    }

    // ======================================================
    // ✅ COMPLETE BOOKING
    // ======================================================
    @Transactional
    public Booking completeBooking(String bookingId) {

        User loggedInUser = getLoggedInUser();

        if (loggedInUser.getRole() != Role.TRADESPERSON) {
            throw new UnauthorizedException("Only tradesperson can complete booking");
        }

        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Booking not found"));

        if (!booking.getTradespersonId().equals(loggedInUser.getId())) {
            throw new UnauthorizedException("You are not authorized to complete this booking");
        }

        if (booking.getStatus() != BookingStatus.ACCEPTED) {
            throw new BadRequestException("Only accepted bookings can be completed");
        }

        booking.setStatus(BookingStatus.COMPLETED);

        Query query = new Query(
                Criteria.where("_id").is(loggedInUser.getId())
                        .and("status").is(Status.BUSY)
        );

        Update update = new Update().set("status", Status.AVAILABLE);

        mongoTemplate.updateFirst(query, update, User.class);

        log.info("Booking {} completed by tradesperson {}", bookingId, loggedInUser.getId());

        return bookingRepository.save(booking);
    }

    // ======================================================
    // ✅ CANCEL BOOKING
    // ======================================================
    @Transactional
    public Booking cancelBooking(String bookingId, String reason) {

        User loggedInUser = getLoggedInUser();

        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Booking not found"));

        BookingStatus currentStatus = booking.getStatus();

        if (currentStatus == BookingStatus.COMPLETED ||
                currentStatus == BookingStatus.REJECTED ||
                currentStatus == BookingStatus.CANCELLED) {

            throw new ConflictException("This booking cannot be cancelled");
        }

        if (loggedInUser.getRole() == Role.USER) {

            if (!booking.getUserId().equals(loggedInUser.getId())) {
                throw new UnauthorizedException("You are not authorized to cancel this booking");
            }

            booking.setCancelledBy(CancellationBy.USER);

        } else if (loggedInUser.getRole() == Role.TRADESPERSON) {

            if (!booking.getTradespersonId().equals(loggedInUser.getId())) {
                throw new UnauthorizedException("You are not authorized to cancel this booking");
            }

            booking.setCancelledBy(CancellationBy.TRADESPERSON);

        } else {
            throw new UnauthorizedException("Unauthorized role");
        }

        if (currentStatus == BookingStatus.ACCEPTED) {

            Query query = new Query(
                    Criteria.where("_id").is(booking.getTradespersonId())
                            .and("status").is(Status.BUSY)
            );

            Update update = new Update().set("status", Status.AVAILABLE);

            mongoTemplate.updateFirst(query, update, User.class);
        }

        booking.setStatus(BookingStatus.CANCELLED);
        booking.setCancellationReason(reason);
        booking.setCancelledAt(LocalDateTime.now());

        log.info("Booking {} cancelled by {}", bookingId, loggedInUser.getRole());

        return bookingRepository.save(booking);
    }

    // ======================================================
    // GET METHODS
    // ======================================================

    public Booking getBookingById(String bookingId) {

        User loggedInUser = getLoggedInUser();

        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Booking not found"));

        if (!booking.getUserId().equals(loggedInUser.getId()) &&
                !booking.getTradespersonId().equals(loggedInUser.getId())) {

            throw new UnauthorizedException("You are not authorized to view this booking");
        }

        return booking;
    }

    public Page<Booking> getBookingsByUser(BookingStatus status, int page, int size) {

        User loggedInUser = getLoggedInUser();

        if (loggedInUser.getRole() != Role.USER) {
            throw new UnauthorizedException("Only users can view their bookings");
        }

        Pageable pageable = PageRequest.of(
                page,
                size,
                Sort.by("createdAt").descending()
        );

        return (status != null)
                ? bookingRepository.findByUserIdAndStatus(loggedInUser.getId(), status, pageable)
                : bookingRepository.findByUserId(loggedInUser.getId(), pageable);
    }

    public Page<Booking> getBookingsByTradesperson(BookingStatus status, int page, int size) {

        User loggedInUser = getLoggedInUser();

        if (loggedInUser.getRole() != Role.TRADESPERSON) {
            throw new UnauthorizedException("Only tradesperson can view bookings");
        }

        Pageable pageable = PageRequest.of(
                page,
                size,
                Sort.by("createdAt").descending()
        );

        return (status != null)
                ? bookingRepository.findByTradespersonIdAndStatus(loggedInUser.getId(), status, pageable)
                : bookingRepository.findByTradespersonId(loggedInUser.getId(), pageable);
    }

    public BookingStatsDTO getBookingStats() {

        User loggedInUser = getLoggedInUser();

        Criteria criteria = (loggedInUser.getRole() == Role.USER)
                ? Criteria.where("userId").is(loggedInUser.getId())
                : Criteria.where("tradespersonId").is(loggedInUser.getId());

        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(criteria),
                Aggregation.group("status").count().as("count")
        );

        AggregationResults<org.bson.Document> results =
                mongoTemplate.aggregate(
                        aggregation,
                        Booking.class,
                        org.bson.Document.class
                );

        long total = 0;
        long pending = 0;
        long accepted = 0;
        long completed = 0;
        long cancelled = 0;
        long rejected = 0;

        for (org.bson.Document doc : results.getMappedResults()) {

            String status = doc.getString("_id");
            long count = ((Number) doc.get("count")).longValue();

            total += count;

            switch (status) {
                case "PENDING":
                    pending = count;
                    break;

                case "ACCEPTED":
                    accepted = count;
                    break;

                case "COMPLETED":
                    completed = count;
                    break;

                case "CANCELLED":
                    cancelled = count;
                    break;

                case "REJECTED":
                    rejected = count;
                    break;
            }
        }

        long active = accepted; // Active bookings = accepted bookings

        return new BookingStatsDTO(
                total,
                pending,
                accepted,
                completed,
                cancelled,
                rejected,
                active
        );
    }
}