package com.fixlocal.model;

public enum NotificationType {
    BOOKING_CREATED,
    BOOKING_ACCEPTED,
    BOOKING_REJECTED,
    BOOKING_COMPLETED,
    BOOKING_CANCELLED
}