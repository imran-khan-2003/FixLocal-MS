package com.fixlocal.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Document(collection = "bookings")
@CompoundIndexes({
        @CompoundIndex(name = "user_idx", def = "{'userId': 1}"),
        @CompoundIndex(name = "tradesperson_idx", def = "{'tradespersonId': 1}"),

        // 🔥 Index for slot conflict checking
        @CompoundIndex(
                name = "tradesperson_timeslot_idx",
                def = "{'tradespersonId': 1, 'bookingStartTime': 1, 'bookingEndTime': 1}"
        )
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Booking {

    @Id
    private String id;

    @Indexed
    private String userId;

    @Indexed
    private String tradespersonId;

    // 🔥 NEW TIME SLOT
    @Indexed
    private LocalDateTime bookingStartTime;

    @Indexed
    private LocalDateTime bookingEndTime;

    // 🔥 SERVICE DETAILS
    private String serviceAddress;

    private String serviceDescription;

    private Double price;

    @Builder.Default
    private BookingStatus status = BookingStatus.PENDING;

    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    private CancellationBy cancelledBy;

    private String cancellationReason;

    private LocalDateTime cancelledAt;
}