package com.fixlocal.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.*;
import org.springframework.data.mongodb.core.mapping.Document;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.time.LocalDateTime;

@Document(collection = "users")

@CompoundIndexes({
        @CompoundIndex(name = "city_occupation_idx", def = "{'workingCity': 1, 'occupation': 1}"),
        @CompoundIndex(name = "role_city_idx", def = "{'role': 1, 'workingCity': 1}")
})

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    private String id;

    private String name;

    @Indexed(unique = true)
    private String email;

    @JsonIgnore
    private String password;

    @Indexed
    private Role role;

    // searchable text field
    @TextIndexed
    private String occupation;

    @Indexed
    private String workingCity;

    private Integer experience;

    // worker availability
    @Builder.Default
    private boolean available = true;

    @Builder.Default
    private Status status = Status.AVAILABLE;

    @Builder.Default
    private Double averageRating = 0.0;

    @Builder.Default
    private Integer totalReviews = 0;

    @Builder.Default
    private boolean blocked = false;

    @Builder.Default
    private boolean verified = true;

    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();
}