package com.fixlocal.model;

public enum Status {
    AVAILABLE,
    BOOKED,
    OFFLINE,
    BUSY
}
