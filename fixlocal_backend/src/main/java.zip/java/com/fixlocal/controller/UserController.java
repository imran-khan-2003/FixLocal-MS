package com.fixlocal.controller;

import com.fixlocal.dto.UpdateUserRequest;
import com.fixlocal.dto.UserResponseDTO;
import com.fixlocal.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @GetMapping("/me")
    public UserResponseDTO getMyProfile(Authentication authentication) {
        return userService.getMyProfile(authentication.getName());
    }

    @PutMapping("/me")
    public UserResponseDTO updateMyProfile(
            Authentication authentication,
            @Valid @RequestBody UpdateUserRequest request) {

        return userService.updateMyProfile(authentication.getName(), request);
    }
}